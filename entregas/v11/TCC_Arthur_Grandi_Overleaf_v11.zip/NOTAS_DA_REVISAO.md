# Notas da revisão V10 → V11

## Alterações incorporadas

- Introdução: explica a passagem da V8 apresentada para o escopo revisto, conforme esclarecimento do autor. Preserva literalmente objetivos e questão principal da V10.
- Resumo/abstract: apresentam a plataforma implementada e distinguem o antecedente do notebook da avaliação ainda pendente.
- Metodologia: atualiza o fluxo implementado, a revisão do PPC e a preservação do corpus; mantém o cronograma anterior como planejamento, sem certificá-lo como execução.
- Fundamentação: diferencia extração lexical, NER e LLM; acrescenta referências para avaliação e concordância.
- Trabalhos relacionados: compara AMC, o estudo brasileiro sobre competências da SBC e soluções correlatas, sem inventar clientes ou adoção institucional.
- Capítulo 4: documenta React/FastAPI/Python, fluxos, M1/M2/M3/A1/A2, fórmulas I1–I8, arquitetura em TikZ, SQLite/Supabase, interface e limitações.
- Capítulo 5: preserva os valores históricos atribuídos ao notebook e apresenta protocolo com corpus, parâmetros, anotação, suporte, métricas, comparações opcionais e ameaças à validade.
- Considerações finais: diferencia implementação e avaliação, mantendo trilhas individuais como trabalho futuro.
- Apêndices: guia proposto de anotação com exemplos didáticos e manifesto de reprodução com correspondência aos módulos.

## Procedência e limites

1. Fonte principal: TCC_Arthur_Grandi_Overleaf_v10 (1).zip; main.tex original SHA-256 30f8d3ce5730b794e1eb09774a0297d5a69393232231b93c2fea9ab23c126c6c. O arquivo anexado não foi modificado.
2. Histórico de escopo: PDFs V8 e V9 fornecidos pelo autor e confirmação, nesta conversa, do acordo sobre o reposicionamento. Não foi inventada uma ata ou data específica da decisão.
3. Implementação: revisão 8300112985bbc873116182feaa4dd3c772677841 e documentação técnica do repositório. O código da aplicação não foi alterado para gerar a V11.
4. Notebook: os valores de 265 vagas, 151 páginas, 45/14/12 tecnologias e 26,67% provêm da V10. O notebook/corpus não foi recuperado ou reproduzido para esta versão.
5. Persistência: o texto apresenta a observação somente leitura já registrada em 11/11/2026 às 20h27 de São Paulo. Não foi feita nova consulta ou alteração no Supabase durante a produção da V11.
6. Referências: números principais de BRASSCOM e ACATE foram conferidos nas fontes acessadas em 12/11/2026. O artigo de Ferreira e colaboradores foi conferido na página da SBC. Metadados/resumos do AMC e das referências adicionadas foram consultados no Crossref. As demais referências da V10 foram preservadas, sem alegação de revisão bibliográfica exaustiva.
7. Novas referências: Cohen (1960), Sokolova e Lapalme (2009), Ji e colaboradores (2023) e revisão identificada do código do projeto. O sobrenome composto Parreira Júnior foi corrigido na apresentação bibliográfica.

## Pendências acadêmicas, sem resultados presumidos

- Recuperar e preservar o notebook histórico, o PPC e as bases de vagas.
- Consolidar corpus elegível para o recorte, com datas e metadados.
- Definir a partição desenvolvimento/teste, concluir a curadoria e congelar o vocabulário.
- Executar anotação humana e avaliação; registrar participantes, protocolo, suporte e resultados.
- Interpretar lacunas e indicadores com as evidências do corpus.
- Conferir exigências institucionais, referências remanescentes e atribuição das contribuições e ferramentas de apoio.

Essas pendências não exigem alterar os objetivos. A V11 documenta o estado atual e o procedimento necessário ao fechamento do estudo.
