# TCC de Arthur Annes Grandi — versão 11

Projeto editável preparado em 12/11/2026, no horário de São Paulo, a partir do ZIP da V10. O PDF é uma versão de revisão acadêmica com implementação documentada e avaliação empírica ainda pendente.

## Abrir no Overleaf

1. No Overleaf, escolha **Novo projeto → Carregar projeto**.
2. Envie **TCC_Arthur_Grandi_Overleaf_v11.zip**.
3. Confirme **main.tex** como arquivo principal e **pdfLaTeX** como compilador.
4. Recompile. As referências usam BibTeX e abntex2cite.

O projeto usa abntex2, TikZ e os pacotes LaTeX declarados em main.tex, disponíveis no TeX Live do Overleaf. Não exige acesso à aplicação, ao Supabase ou a credenciais. O ZIP contém somente fontes, figura institucional e notas da revisão.

Para compilar localmente com TeX Live, abnTeX2 e português:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

Alternativa: pdflatex main, bibtex main, pdflatex main, pdflatex main.

## Organização

- main.tex: configuração, capa, folha de rosto, resumo, abstract, listas e inclusão dos capítulos.
- capitulos/: introdução, fundamentação, trabalhos relacionados, desenvolvimento, resultados/protocolo, conclusão e apêndices.
- referencias.bib: referências preservadas da V10 e acréscimos.
- Figuras/: logotipo institucional original.
- NOTAS_DA_REVISAO.md: alterações, origem das evidências e pendências.

## Escopo preservado

A V8 foi apresentada no TCC I; o autor confirmou que a mudança de escopo foi acordada naquela ocasião. A V9/V10 registra o foco revisto de análise curricular. Na V11, o objetivo geral, os seis específicos e a questão principal da V10 foram preservados.

Os números do notebook permanecem como resultados históricos relatados na V10. Nenhuma nova coleta, execução por LLM, anotação humana ou métrica de desempenho foi produzida para preencher o texto. As tabelas prospectivas identificam o que ainda precisa ser executado.

O modelo institucional e os nomes/papéis de orientação foram mantidos da V10. A conferência final das exigências da instituição e do conteúdo acadêmico cabe à revisão do autor e dos orientadores.
